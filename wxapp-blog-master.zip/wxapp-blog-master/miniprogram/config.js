/*
Made By xuhuai
使用说明地址：https://github.com/xuhuai66/wxapp-blog
*/

var data= {
  shareTitle: '宅梦网-每天进步一点点',//分享标题
  shareImg:'https://graph.baidu.com/resource/112675bb0d73012a8feb901562498965.jpg',//分享图地址
  posterImg:'https://img4d.xiaoying.tv/20190708/zao6vv/478wfPX358.jpg',//海报中心图生成地址，自己替换
  Qrcode:'https://qiniu.98api.cn/blog/Qrcode.php',//后端二维码生成地址
  GZHcj:'https://qiniu.98api.cn/blog/gzhcj.php',//公众号采集接口地址，可以不改，就用我的
  VideoAd: 'adunit-bd3972c03b6d61a5',//激励广告代码
  BannerAd: 'adunit-59f62dbaaeee6bba', //横幅广告代码
  InterstitialAd: 'adunit-c9f9a58a0c00ec43'//插屏广告代码
}

module.exports = {
  data: data,
}

