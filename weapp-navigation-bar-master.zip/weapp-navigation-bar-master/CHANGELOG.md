# weapp-navigation-bar
## v1.1.0
1. 增加normal风格的返回按钮，旧版本的定义为simple风格，支持两种风格切换。
2. 点击返回按钮和点击首页按钮，支持在外部绑定事件,使用方法，请参考example。[ISSUE #6](https://github.com/mulook/weapp-navigation-bar/issues/6)
## v1.0.2
1. 修复安卓系统下，页面滚动指定距离，切换导航栏隐藏不全的问题。[ISSUE #3](https://github.com/mulook/weapp-navigation-bar/issues/3)
## v1.0.1
1. 新增支持页面滚动指定距离，切换导航栏的显示或隐藏。[ISSUE #1](https://github.com/mulook/weapp-navigation-bar/issues/1)
## v1.0.0
1. 可根据手机状态栏高度适配。
2. 可自定义设置包括字体颜色、字体大小、背景颜色、无标题、导航栏是否置顶。
3. 可自动识别是否首页launch。